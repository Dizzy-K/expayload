/*
 * $Id: hdn_decode.h,v 1.2 2002/08/28 12:34:53 xvr Exp $
 * Created: 08/21/2002
 *
 * xvr (c) 2002-2004
 * xvr@xvr.net
 */

#ifndef _HDN_DECODE_H_
#define _HDN_DECODE_H_

#include "hydan.h"

int hdn_decode_main (int argc, char **argv);

#endif
